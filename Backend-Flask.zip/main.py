from flask import Flask,render_template,request, url_for
from sklearn.externals.joblib import load

#EDA Packages
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

app = Flask(__name__)

def pie_chart(new_predictions):
	nb_ones = np.count_nonzero(new_predictions)
	nb_zeros = new_predictions.shape[0] - nb_ones
	count = [nb_zeros, nb_ones]
	labels = ["Above", "Below"]
	plt.pie(count, labels = labels, startangle=90)
	plt.savefig("piechart.png")

@app.route("/")
def index():
	return render_template("index.html")

@app.route("/")
def predict(test_set):
	for key in test_set:
		if "sensor" in key:
			test_set[key + "_na"] = [1 if test_set[key][i] == "na" else 0 for i in range(len(test_set[key]))]

	new_X = test_set.iloc[:, 1:].values
	new_X = np.where(new_X == "na", 0, new_X)
	sc = load("std_scaler.bin")
	new_X = sc.fit_transform(new_X)

	from keras.models import model_from_json
	json_file = open("classifier.json", "r")
	loaded_json = json_file.read()
	json_file.close()
	classifier = model_from_json(loaded_json)
	classifier.load_weights("weights.h5")

	new_predictions = classifier.predict(new_X)
	new_predictions = new_predictions > 0.5
	np.savetxt("test_results.txt", new_predictions, fmt="%d")

	with open("test_results.txt", "r") as pred_file:
		fout = open("results_1.txt", "w")
		fout.write("id,target\n")
		for idx, val in enumerate(pred_file):
			fout.write(str(str(idx + 1) + "," + str(val)))

	return render_template("index.html", new_predictions)


@app.route("/", methods=['POST'])
def read_file():
	if request.method == 'POST':
		try:
			file = request.files['file']
			df = pd.read_csv(file)
		except:
			url = "https://raw.githubusercontent.com/DeepBhat/ConocoPhillipsDatathon/master/equip_failures_test_set.csv"
			df = pd.read_csv(url)

		output = predict(df)
		pie_chart(output)

	return render_template('results.html', output) # put any vaiables for result.html here



if __name__ == '__main__':
	app.run(host="127.0.0.1",port=8080,debug=True)